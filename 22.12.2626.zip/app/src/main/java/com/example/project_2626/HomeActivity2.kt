package com.example.project_2626

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HomeActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home2)
    }
}